/******************************************************************************
* Zowi LED Matrix Library
* 
* @version 20150710
* @author Raul de Pablos Martin
*         José Alberca Pita-Romero (Mouth's definitions)
******************************************************************************/

#include "LedMatrix.h"

#if defined(ARDUINO) && ARDUINO >= 100
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

//*****************************************************************************************************
// add code _ 2021-05-15
//*****************************************************************************************************
typedef struct __attribute__((packed)) {
  unsigned char addr;
  unsigned char value;
} dotMatrix_data_t;

void init_spi();
void write_dotMatrix(unsigned char addr, unsigned char value);
void write_dotMatrixStream(dotMatrix_data_t* source, unsigned char length);
void rotate_table(unsigned char* output, unsigned char* input);

dotMatrix_data_t buffer_spi;
volatile unsigned char flg_dotMatrix;

ISR(SPI_STC_vect) {
  if(flg_dotMatrix & 0x40) {
    flg_dotMatrix &= ~0XC0;
    PORTB |= 0x04;
  }
  else {
    PORTB &= ~0x04;
    flg_dotMatrix |= 0x40;
    SPDR = buffer_spi.value;
  }
}


void init_spi() {
  DDRB |= 0x2c;
  PORTB |= 0x04;
  
  SPCR = 0xd3;
  SPSR = 0x00;
}

void write_dotMatrix(unsigned char addr, unsigned char value) {
  buffer_spi.addr = addr;
  buffer_spi.value = value;

  flg_dotMatrix |= 0X80;
  PORTB &= ~0x04;
  SPDR = buffer_spi.addr;
  while(flg_dotMatrix & 0X80);
}

void write_dotMatrixStream(dotMatrix_data_t* source, unsigned char length) {
  while(length--) {
    write_dotMatrix(source[length].addr, source[length].value);
  }
}

void rotate_table(unsigned char* output, unsigned char* input) {
  unsigned char buffer[8] = {0x00,};
  unsigned char row;
  unsigned char col;
  
  for(row=0;row<8;row++) {
    for(col=0;col<8;col++) {
      if(input[7-col] & (1 << row)) buffer[row] |= 1 << col;
    }
  }
  for(row=0;row<8;row++) output[row] = buffer[row];
}

//*****************************************************************************************************
//*****************************************************************************************************


LedMatrix::LedMatrix(char ser_pin, char clk_pin, char rck_pin) {
}
void LedMatrix::init() {
  init_spi();
	write_dotMatrix(0x0c,0x01);
	write_dotMatrix(0x09,0x00);
	write_dotMatrix(0x0a,0x03);
	write_dotMatrix(0x0b,0x07);
	write_dotMatrix(0x0f,0x00);
	clearMatrix();
}

void LedMatrix::writeFull(unsigned long value) {
	unsigned char source[8] = {
		0,
		0,
		((value>>(6*(6-2)))&0x3f)<<1,
		((value>>(6*(6-3)))&0x3f)<<1,
		((value>>(6*(6-4)))&0x3f)<<1,
		((value>>(6*(6-5)))&0x3f)<<1,
		((value>>(6*(6-6)))&0x3f)<<1,
		0
	};
	rotate_table(source,source);
	
	dotMatrix_data_t _buffer[8] = {
		{1,source[0]},
		{2,source[1]},
		{3,source[2]},
		{4,source[3]},
		{5,source[4]},
		{6,source[5]},
		{7,source[6]},
		{8,source[7]}
	};
	write_dotMatrixStream(_buffer,8);
}

unsigned long LedMatrix::readFull(void) {
	return 0L;
}

void LedMatrix::setLed(char row, char column) {

}

void LedMatrix::unsetLed(char row, char column) {

}

void LedMatrix::clearMatrix(void) {
	dotMatrix_data_t _buffer[8] {
    {1,0},
    {2,0},
    {3,0},
    {4,0},
    {5,0},
    {6,0},
    {7,0},
    {8,0}
  };

  write_dotMatrixStream(_buffer,8);
}

void LedMatrix::setEntireMatrix(void) {
	dotMatrix_data_t _buffer[8] {
    {1,0xff},
    {2,0xff},
    {3,0xff},
    {4,0xff},
    {5,0xff},
    {6,0xff},
    {7,0xff},
    {8,0xff}
  };

  write_dotMatrixStream(_buffer,8);
}